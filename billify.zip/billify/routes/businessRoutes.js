const express = require('express');
const router = express.Router();
const Business = require('../models/Business');

router.post('/', async (req, res) => {
    try {
        console.log('📥 Received:', req.body);
        const business = new Business(req.body);
        await business.save();
        res.status(201).json({ message: 'Business details saved successfully' });
    } catch (err) {
        console.error('❌ Failed to save business:', err);
        
        // Check for validation errors
        if (err.name === 'ValidationError') {
            const validationErrors = {};
            
            // Extract specific field errors
            for (const field in err.errors) {
                validationErrors[field] = err.errors[field].message;
            }
            
            return res.status(400).json({ 
                error: 'Validation failed', 
                validationErrors 
            });
        }
        
        // Handle other errors
        res.status(500).json({ 
            error: 'Internal server error', 
            details: err.message 
        });
    }
});

module.exports = router;
