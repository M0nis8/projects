    require('dotenv').config();
    const express = require('express');
    const mongoose = require('mongoose');
    const cors = require('cors');
    const path = require('path');
    const cookieParser = require('cookie-parser');

    const userRoutes = require('./routes/userRoutes');
    const businessRoutes = require('./routes/businessRoutes'); // ✅ THIS ONE ONLY

    const app = express();
    const PORT = process.env.PORT || 3000;

    // Middleware
    app.use(cors({ origin: 'http://localhost:3000', credentials: true }));
    app.use(cookieParser());
    app.use(express.json());

    // Serve static files
    app.use(express.static('public'));

    // MongoDB connection
    mongoose.connect(process.env.MONGO_URI)
    .then(() => console.log('✅ Connected to MongoDB'))
    .catch(err => {
        console.error('❌ MongoDB connection error:', err);
        console.error('Connection string:', process.env.MONGO_URI.replace(/\/\/.*?@/, '//***:***@'));
    });


    // Routes
    app.use('/auth', userRoutes);
    app.use('/api/users', userRoutes);
    app.use('/api/businesses', businessRoutes); // ✅ Only one route
    app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
    });

    // Start server
    app.listen(PORT, () => console.log(`🚀 Server running at http://localhost:${PORT}`));
