const mongoose = require('mongoose');

const businessSchema = new mongoose.Schema({
  ownerName: { type: String, required: true },
  countryCode: { type: String },
  phone: { type: String, required: true },
  businessName: { type: String, required: true },
  businessType: { type: String, required: true },
  gstNumber: { type: String },
  businessRegNumber: { type: String, required: true },
  address: {
    addressLine1: { type: String, required: true },
    city: { type: String, required: true },
    state: { type: String, required: true },
    postalCode: { type: String, required: true },
    country: { type: String, required: true }
  }
});

module.exports = mongoose.models.Business || mongoose.model('Business', businessSchema);
